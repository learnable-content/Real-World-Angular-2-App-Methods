"use strict";
exports.FIREBASE_CONFIG = {
    apiKey: "AIzaSyBz6-vg95znmMDi8w0ZYub2ewSiWTeQd90",
    authDomain: "bugged-out.firebaseapp.com",
    databaseURL: "https://bugged-out.firebaseio.com",
    storageBucket: "bugged-out.appspot.com",
    messagingSenderId: "57120028829"
};
//# sourceMappingURL=constants.js.map